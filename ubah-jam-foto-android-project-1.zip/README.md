# UBAH JAM FOTO Android wrapper
Android WebView shell for the HTML app. GitHub Actions builds a debug APK.
Upload the contents of this project into the repository root (keep folder paths).
Then open Actions → Build UBAH JAM FOTO APK → Run workflow, or wait for push build.
Download the APK from the workflow run's Artifacts.
