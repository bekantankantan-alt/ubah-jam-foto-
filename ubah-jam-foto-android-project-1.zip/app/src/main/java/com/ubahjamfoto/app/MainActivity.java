package com.ubahjamfoto.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.os.Build;
import android.os.Environment;
import android.widget.Toast;
import java.io.*;
import android.util.Base64;

public class MainActivity extends Activity {
    WebView web;
    ValueCallback<Uri[]> fileCallback;
    static final int FILE_PICK=101;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        web=new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=cb;
                Intent i=new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(Intent.createChooser(i,"Pilih foto"),FILE_PICK);
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    public class AndroidBridge {
        @JavascriptInterface public void saveJpg(String dataUrl, String filename){
            try{
                String b64=dataUrl.substring(dataUrl.indexOf(",")+1);
                byte[] bytes=Base64.decode(b64,Base64.DEFAULT);
                ContentValues values=new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
                values.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
                if(Build.VERSION.SDK_INT>=29){
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES+"/Ubah Jam Foto");
                    Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
                    if(uri==null) throw new IOException("Tidak bisa membuat file");
                    try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(bytes);}
                }else{
                    File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),"Ubah Jam Foto");
                    if(!dir.exists())dir.mkdirs();
                    try(FileOutputStream out=new FileOutputStream(new File(dir,filename))){out.write(bytes);}
                }
                runOnUiThread(()->Toast.makeText(MainActivity.this,"JPG tersimpan di Pictures/Ubah Jam Foto",Toast.LENGTH_LONG).show());
            }catch(Exception e){
                runOnUiThread(()->Toast.makeText(MainActivity.this,"Gagal menyimpan JPG: "+e.getMessage(),Toast.LENGTH_LONG).show());
            }
        }
    }
    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req==FILE_PICK && fileCallback!=null){
            Uri[] results=(res==RESULT_OK && data!=null && data.getData()!=null)?new Uri[]{data.getData()}:null;
            fileCallback.onReceiveValue(results); fileCallback=null;
        }
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
